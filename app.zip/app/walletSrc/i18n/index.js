'use strict';

const zh = require('./zh.js');
const en = require('./en.js');

module.exports = {
    'zh-CN': zh,
    'zh': zh,
    'en': en
};