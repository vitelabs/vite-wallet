'use strict';

module.exports = {
    'cancel': '取消',
    'close': '关闭',
    'yes': '确定',
    'quitWallet': '是否确定退出?',
    'reload': '重新加载'
};