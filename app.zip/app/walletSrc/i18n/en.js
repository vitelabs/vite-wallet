'use strict';

module.exports = {
    'cancel': 'Cancel',
    'close': 'close',
    'yes': 'Yes',
    'quitWallet': 'Quit Vite wallet ?',
    'reload': 'reload'
};