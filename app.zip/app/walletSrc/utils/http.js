'use strict';

var _require = require('electron');

const net = _require.net;

const querystring = require('querystring');

const protocol = 'https:';
const hostname = 'test.vite.net';
const TIMEOUT = 10000;

function setHeader(_ref) {
    let request = _ref.request;
    var _ref$headers = _ref.headers;
    let headers = _ref$headers === undefined ? {} : _ref$headers;
    var _ref$type = _ref.type;
    let type = _ref$type === undefined ? 'json' : _ref$type;

    for (let key in headers) {
        request.setHeader(key, headers[key]);
    }
    if (type === 'json') {
        request.setHeader('content-type', 'application/json; charset=utf-8');
    } else {
        request.setHeader('content-type', 'application/x-www-form-urlencoded; charset=utf-8');
    }
}

function parseReq(_ref2) {
    let params = _ref2.params;
    var _ref2$type = _ref2.type;
    let type = _ref2$type === undefined ? 'json' : _ref2$type,
        method = _ref2.method;

    if (method === 'GET') {
        return querystring.stringify(params);
    }

    let text = '';
    if (type !== 'json') {
        for (let key in params) {
            text += `${key}=${params[key]}&`;
        }
    } else {
        text = JSON.stringify(params);
    }

    return text;
}

module.exports = function (_ref3) {
    let path = _ref3.path,
        params = _ref3.params;
    var _ref3$method = _ref3.method;
    let method = _ref3$method === undefined ? 'POST' : _ref3$method;
    var _ref3$headers = _ref3.headers;
    let headers = _ref3$headers === undefined ? {} : _ref3$headers;
    var _ref3$type = _ref3.type;
    let type = _ref3$type === undefined ? 'json' : _ref3$type;

    if (!global.netStatus) {
        return Promise.reject({
            code: -50003,
            message: 'Client net error'
        });
    }

    // Request text
    let reqText = parseReq({ params, type, method });

    if (method === 'GET') {
        path += `?${reqText}`;
    }

    const request = net.request({
        method,
        protocol,
        hostname,
        path
    });

    // setHeader
    setHeader({
        request, headers, type
    });

    return new Promise((res, rej) => {
        let bodyData = '';

        let httpTimeout = setTimeout(() => {
            request.abort();
            httpRej({
                code: -50002,
                message: 'Http server timeout.'
            });
        }, TIMEOUT);

        let cancelTimeout = () => {
            clearTimeout(httpTimeout);
            httpTimeout = null;
        };

        let httpRej = (_ref4) => {
            let code = _ref4.code,
                message = _ref4.message;

            cancelTimeout();
            return rej({
                code, message
            });
        };

        request.on('response', response => {
            response.on('data', chunk => {
                bodyData += chunk;
            });

            response.on('end', () => {
                if (response.statusCode !== 200) {
                    return httpRej({
                        code: response.statusCode,
                        message: 'Http server error.'
                    });
                }

                try {
                    var _JSON$parse = JSON.parse(bodyData);

                    let code = _JSON$parse.code,
                        msg = _JSON$parse.msg,
                        data = _JSON$parse.data,
                        error = _JSON$parse.error;

                    if (code !== 0) {
                        return httpRej({
                            code,
                            message: msg || error
                        });
                    }

                    res(data);
                } catch (err) {
                    return httpRej({
                        code: -50001,
                        message: 'Http responce parse error.'
                    });
                }
            });
        });

        method === 'POST' && request.write(reqText);
        request.end();
    });
};