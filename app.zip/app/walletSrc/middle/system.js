'use strict';

var _require = require('electron');

const clipboard = _require.clipboard,
      app = _require.app;

var _require2 = require('../utils/log.js');

const add = _require2.add;


class System {
    constructor() {}

    clipboardWrite(text) {
        clipboard.writeText(text);
    }

    setLocale(locale) {
        if (global.userLocale !== locale) {
            global.walletLog.info(`locale-${locale}`);
        }
        global.userLocale = locale;
    }

    getLocale() {
        return app.getLocale();
    }

    log(msg) {
        add(msg);
    }
}

module.exports = System;