'use strict';

var _require = require('electron');

const shell = _require.shell,
      dialog = _require.dialog;

const version = require('../version.json');
const request = require('../utils/http.js');

module.exports = function () {
    request({
        path: '/api/walletapp/version',
        params: {
            code: version.code,
            channel: version.channel
        },
        method: 'GET'
    }).then((_ref) => {
        let codeName = _ref.codeName,
            appUrl = _ref.appUrl,
            message = _ref.message,
            isForce = _ref.isForce;

        if (!isForce || !global.WALLET_WIN || global.WALLET_WIN.isDestroyed()) {
            global.WALLET_WIN = null;
            return;
        }

        dialog.showMessageBox({
            type: 'info',
            title: `${codeName} update`,
            message: `${message}`,
            buttons: ['no thanks', 'download']
        }, id => {
            id === 1 && shell.openExternal(appUrl);
        });
    }).catch(err => {
        console.log(err);
    });
};