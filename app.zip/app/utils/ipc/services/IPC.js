'use strict';

const Defaults = require('../entities/Defaults.js'),
      Client = require('../dao/client.js'),
      util = require('util');

class IPC {
    constructor() {
        Object.defineProperties(this, {
            config: {
                enumerable: true,
                writable: true,
                value: new Defaults()
            },
            connectTo: {
                enumerable: true,
                writable: false,
                value: connect
            },
            disconnect: {
                enumerable: true,
                writable: false,
                value: disconnect
            },
            of: {
                enumerable: true,
                writable: true,
                value: {}
            },
            log: {
                enumerable: true,
                writable: false,
                value: log
            }
        });
    }
}

function log() {
    if (this.config.silent) {
        return;
    }

    for (var _len = arguments.length, args = Array(_len), _key = 0; _key < _len; _key++) {
        args[_key] = arguments[_key];
    }

    for (let i = 0, count = args.length; i < count; i++) {
        if (typeof args[i] != 'object') {
            continue;
        }

        args[i] = util.inspect(args[i], {
            depth: this.config.logDepth,
            colors: this.config.logInColor
        });
    }

    this.config.logger(args.join(' '));
}

function disconnect(id) {
    if (!this.of[id]) {
        return;
    }

    this.of[id].explicitlyDisconnected = true;

    this.of[id].off('*', '*');
    if (this.of[id].socket) {
        if (this.of[id].socket.destroy) {
            this.of[id].socket.destroy();
        }
    }

    delete this.of[id];
}

function emptyCallback() {
    //Do Nothing
}

function connect(id, path, callback) {
    if (typeof path == 'function') {
        callback = path;
        path = false;
    }

    if (!callback) {
        callback = emptyCallback;
    }

    if (!id) {
        this.log('Service id required', 'Requested service connection without specifying service id. Aborting connection attempt');
        return;
    }

    if (!path) {
        this.log('Service path not specified, so defaulting to', 'ipc.config.socketRoot + ipc.config.appspace + id', (this.config.socketRoot + this.config.appspace + id).data);
        path = this.config.socketRoot + this.config.appspace + id;
    }

    if (this.of[id]) {
        if (!this.of[id].socket.destroyed) {
            this.log('Already Connected to', id, '- So executing success without connection');
            callback();
            return;
        }
        this.of[id].socket.destroy();
    }

    this.of[id] = new Client(this.config, this.log);
    this.of[id].id = id;
    this.of[id].path = path;

    this.of[id].connect();

    callback(this);
}

module.exports = IPC;